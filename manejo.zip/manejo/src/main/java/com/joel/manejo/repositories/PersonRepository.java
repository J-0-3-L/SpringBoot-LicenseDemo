package com.joel.manejo.repositories;

import com.joel.manejo.models.Person;

public interface PersonRepository extends BaseRepository<Person> {
    
}
