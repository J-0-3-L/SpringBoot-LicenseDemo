package com.joel.manejo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ManejoApplicationTests {

	@Test
	void contextLoads() {
	}

}
